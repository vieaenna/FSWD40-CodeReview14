<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Event;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;



class EventController extends Controller
{

	/**
	* @Route("/", name="event_list")
	*/

	public function homeAction(Request $request){

	    $events = $this->getDoctrine()->getRepository('AppBundle:Event')->findAll();

	    // replace this example code with whatever you need

	    return $this->render('event/index.html.twig', array('events'=>$events));

	}


	/**
     * @Route("/event/list", name="event_view")
     */

    public function listAction(){
        $events = $this->getDoctrine()->getRepository('AppBundle:Event')->findAll();
        return $this->render('event/list.html.twig', array('events'=>$events));
    }

	/**
	* @Route("/event/type/{type}", name="event_type")
	*/

	public function filterAction($type){

		$events = $this->getDoctrine()->getRepository('AppBundle:Event')->find($type);

		return $this->render('event/type.html.twig', array('events' => $events));
	}

	/**
	* @Route("/event/create", name="event_create")
	*/

	public function createAction(Request $request){

	    $event = new Event;

	    $form = $this->createFormBuilder($event)

	    ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

	    ->add('startDate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px', 'id'=>'datepicker')))

	    ->add('endDate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

	    ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

	    ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

	    ->add('capacity', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))	    
		->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('mail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('type', ChoiceType::class, array('choices'=>array('Foodmarket'=>'Foodmarket', 'Musical'=>'Musical', 'Concert'=>'Concert', 'Movie'=>'Movie', 'Party'=>'Party', 'Tasting'=>'Tasting', 'Sport'=>'Sport', 'Festival'=>'Festival'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

	    //submit form
	    ->add('save', SubmitType::class, array('label'=> 'Event hinzufügen', 'attr' => array('class'=> 'btn btn-primary', 'style'=>'margin-top:15px; margin-bottom:50px')))

	    ->getForm();

	    $form->handleRequest($request);

		    if($form->isSubmitted() && $form->isValid()){

		        //fetching data

		        $name = 	$form['name']->getData();
		        $start = 	$form['startDate']->getData();
		        $end = 		$form['endDate']->getData();
		        $description = $form['description']->getData();
		        $image = 	$form['image']->getData();
		        $capacity = $form['capacity']->getData();
		        $address = 	$form['address']->getData();
		        $mail = 	$form['mail']->getData();
		        $phone = 	$form['phone']->getData();
		        $url = 		$form['url']->getData();
		        $type = 	$form['type']->getData();

		        //$now = new\DateTime('now');

		        $event->setName($name);
		        $event->setStartDate($start);
		        $event->setEndDate($end);
		        $event->setDescription($description);
		        $event->setImage($image);
		        $event->setCapacity($capacity);
		        $event->setAddress($address);
		        $event->setMail($mail);
		        $event->setPhone($phone);
		        $event->setUrl($url);
		        $event->setType($type);

		        $em = $this->getDoctrine()->getManager();

		        $em->persist($event);

		        $em->flush();


		        $this->addFlash(
		                'notice',
		                'Event Added'
		                );

		 

		        return $this->redirectToRoute('event_list');

		    }

	    // replace this example code with whatever you need

	    return $this->render('event/create.html.twig', array('form' => $form->createView()));

	}


	/**
	* @Route("/event/details/{id}", name="event_details")
	*/

    public function detailsAction($id){

        $event = $this->getDoctrine()->getRepository('AppBundle:Event')->find($id);

        return $this->render('event/details.html.twig', array('event' => $event));

    }


    /**
    * @Route("/event/edit/{id}", name="event_edit")
    */

    public function editAction( $id, Request $request){

	    $event = $this->getDoctrine()->getRepository('AppBundle:Event')->find($id);


		$event->setName($event->getName());
		$event->setStartDate($event->getStartDate());
		$event->setEndDate($event->getEndDate());
		$event->setDescription($event->getDescription());
		$event->setImage($event->getImage());
		$event->setCapacity($event->getCapacity());
		$event->setAddress($event->getAddress());
		$event->setMail($event->getMail());
		$event->setPhone($event->getPhone());
		$event->setUrl($event->getUrl());
		$event->setType($event->getType());



	    $form = $this->createFormBuilder($event)

	    ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

	    ->add('startDate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

	    ->add('endDate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

	    ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

	    ->add('capacity', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('mail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))	

		->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('type', ChoiceType::class, array('choices'=>array('Foodmarket'=>'Foodmarket', 'Musical'=>'Musical', 'Concert'=>'Concert', 'Movie'=>'Movie', 'Party'=>'Party', 'Tasting'=>'Tasting', 'Sport'=>'Sport', 'Festival'=>'Festival'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

	    //submit form
	    ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-top:15px; margin-bottom:50px')))

	    ->getForm();


	    $form->handleRequest($request);

	    if($form->isSubmitted() && $form->isValid()){

	        //fetching data
	    	$name = 	$form['name']->getData();
	    	$start = 	$form['startDate']->getData();
	    	$end = 		$form['endDate']->getData();
	    	$description = $form['description']->getData();
	    	$image = 	$form['image']->getData();
	    	$capacity = $form['capacity']->getData();
	    	$address = 	$form['address']->getData();
	    	$mail = 	$form['mail']->getData();
	    	$phone = 	$form['phone']->getData();
	    	$url = 		$form['url']->getData();
	    	$type = 	$form['type']->getData();

	    	$em = $this->getDoctrine()->getManager();

	    	$event = $em->getRepository('AppBundle:Event')->find($id);

	    	$event->setName($name);
	    	$event->setStartDate($start);
	    	$event->setEndDate($end);
	    	$event->setDescription($description);
	    	$event->setImage($image);
	    	$event->setCapacity($capacity);
	    	$event->setAddress($address);
	    	$event->setMail($mail);
	    	$event->setPhone($phone);
	    	$event->setUrl($url);
	    	$event->setType($type);
	    	
	        $em->flush();

	        $this->addFlash(

	            'notice',
	            'Event Updated'

	            );

	        return $this->redirectToRoute('event_list');

	    }

	    return $this->render('event/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
	}


    /** 
    * @Route("/event/delete/{id}", name="event_delete")
    */

    public function deleteAction($id){

        $em = $this->getDoctrine()->getManager();

        $event = $em->getRepository('AppBundle:Event')->find($id);

        $em->remove($event);

        $em->flush();


        $this->addFlash(

                'notice',
                'Event Removed'

                );

        return $this->redirectToRoute('event_list');

    }

}